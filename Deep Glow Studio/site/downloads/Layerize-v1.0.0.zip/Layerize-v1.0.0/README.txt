Layerize v1.0.0 — HTML to After Effects Layers
Made by Towfiq Islam (Lumas Creative)

NOTE (Static Mirror Notice): Upstream binary archive could not be fetched directly inside the sandboxed build environment; this placeholder archive preserves the exact download route (/downloads/Layerize-v1.0.0.zip) and includes the demo HTML composition.
